// SPDX-License-Identifier: GPL-2.0
/*  Copyright(c) 2017-2018 Jesper Dangaard Brouer, Red Hat Inc.
 *
 * XDP monitor tool, based on tracepoints
 */
#include "xdp_sample.bpf.h"

char _license[] SEC("license") = "GPL";
